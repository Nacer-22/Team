# HAX_TEAM Portal

Red-and-black HAX_TEAM portal with server-validated access keys, a protected administration panel, a remaining-time gear, and the owner's Happ deep link. Existing node definitions and tunnel/interceptor source files are retained.

## Run locally

Requires Node.js 18 or newer.

```bash
npm install
cp .env.example .env
# Edit .env and set a private ADMIN_PASSWORD
npm start
```

Open `http://localhost:3000`. The administration panel is at `/admin`; its HTTP Basic username is `admin`.

## Environment variables

- `ADMIN_PASSWORD` — required secret for the admin panel. Set it in the host's secret/environment settings. Do not put the production value in source code, HTML, or a committed `.env` file.
- `HAX_DATA_DIR` — optional writable directory for `database.json`. Use persistent storage in production or keys will be lost on redeploy/restart.
- `PORT` — supplied by most hosting platforms.
- `HAX_TUNNEL_PORT` — optional local UDP tunnel listener port; defaults to `15000`.

## Key lifecycle

1. An administrator signs in at `/admin` and creates a key with a duration.
2. The key remains unactivated until its first successful redemption. The duration starts at that first redemption, and the server binds the key to the supplied device identifier.
3. The portal validates keys using this same deployment's `/api/redeem` endpoint and the same database used by the admin panel. It does not silently create unknown keys.
4. Client sessions are revalidated on page load and periodically. Revoked or expired keys are denied by the server. The browser countdown is only a display; the server is authoritative.
5. Admin extension/revocation changes are applied to future validation requests.

The initial `data/database.json` contains no active keys or saved user identifiers. The live database is ignored by Git. Back up the persistent data volume securely.

## Happ subscription deep link

`ADD SUBSCRIPTION` revalidates the portal key and then opens the exact fixed `happ://` URI supplied by the owner. Happ must be installed and registered to handle the URI. **Important limitation:** opening a fixed, encrypted Happ link is a client-side import action. This portal can deny its own access when a portal key expires or is revoked, but it cannot remotely revoke a profile that has already been imported into Happ. That requires an upstream subscription/profile service that enforces its own expiry and revocation. The fixed URI does not become a per-user expiring URL merely because the portal key has a duration.

## Deploy on Render

The repository includes `render.yaml` for a Node web service, a persistent disk mounted at `/var/data`, and `/health` health checks. To deploy, connect the GitHub repository in Render and create a Blueprint instance from `render.yaml`. Before the first production deploy, set `ADMIN_PASSWORD` as a secret in the service environment. Do not deploy without a persistent disk or a secure admin password.

After deployment, verify `/health`, `/admin`, key creation, first activation, re-login, expiry/revocation, and Happ opening on a device with Happ installed.

## Tests

```bash
npm test
```

Tests use temporary local storage and a test admin password; they do not touch the production database.

## Security notes

- Admin access is protected by HTTP Basic Authentication, timing-safe password comparison, and per-IP failure throttling.
- Admin mutations reject cross-origin requests. JSON request bodies are size-limited and validated.
- Security headers are applied and server-only/data paths are not served as static assets.
- Store `ADMIN_PASSWORD` and the persistent database only in trusted hosting settings/storage. Use HTTPS.

The legacy UDP tunnel and packet-interceptor modules were retained, not independently audited or certified as a complete production VPN/proxy service. Their availability and routing need separate environment-specific verification.
