const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const db = require('./data/db');
const interceptor = require('./src/engine/packet_interceptor');
const gameTunnel = require('./src/engine/game_tunnel');

// Start active UDP game tunnel
gameTunnel.start();

// Initialize interceptor with saved features
interceptor.setFeatures(db.get().global_features);

const PORT = process.env.PORT || 3000;
const ROOT_DIR = __dirname;

// Set ADMIN_PASSWORD in the hosting dashboard. Never commit the admin code to the repository.
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const adminFailures = new Map();

// كلمة مرور الأدمن (يمكن التحكم بها عبر متغيرات البيئة أو استخدام القيمة الافتراضية)

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.ttf': 'font/ttf'
};

// SSE Clients set
const sseClients = new Set();

function broadcastEvent(eventName, data) {
  for (const client of sseClients) {
    try {
      client.write(`event: ${eventName}\ndata: ${JSON.stringify(data)}\n\n`);
    } catch (e) {
      sseClients.delete(client);
    }
  }
}

function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store, max-age=0'
  });
  res.end(JSON.stringify(data));
}

function parseJsonBody(req) {
  return new Promise((resolve) => {
    let body = '';
    let size = 0;
    let tooLarge = false;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > 16 * 1024) {
        tooLarge = true;
        return;
      }
      body += chunk.toString('utf8');
    });
    req.on('end', () => {
      if (tooLarge) return resolve({ __requestError: 413 });
      try {
        const parsed = JSON.parse(body || '{}');
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
          return resolve({ __requestError: 400 });
        }
        resolve(parsed);
      } catch (e) {
        resolve({ __requestError: 400 });
      }
    });
    req.on('error', () => resolve({ __requestError: 400 }));
  });
}

async function readJsonBody(req, res) {
  const body = await parseJsonBody(req);
  if (body && body.__requestError) {
    sendJson(res, body.__requestError, {
      error: body.__requestError === 413 ? 'request body is too large' : 'invalid JSON request body'
    });
    return null;
  }
  return body || {};
}

function isKeyActive(keyRecord) {
  if (!keyRecord || keyRecord.status !== 'active') return false;
  if (!keyRecord.expires_at) return true;
  const expiry = Date.parse(keyRecord.expires_at);
  return Number.isFinite(expiry) && expiry > Date.now();
}

function detectServerDevice(ua = '') {
  let os = 'Unknown OS';
  let model = 'Unknown Device';

  if (/Windows NT 10.0/i.test(ua)) {
    os = 'Windows 10/11 64-bit';
    model = 'Windows PC';
  } else if (/Windows NT 6.3/i.test(ua)) {
    os = 'Windows 8.1';
    model = 'Windows PC';
  } else if (/Windows NT 6.1/i.test(ua)) {
    os = 'Windows 7';
    model = 'Windows PC';
  } else if (/iPhone/i.test(ua)) {
    const v = ua.match(/OS (\d+[_\.]\d+)/);
    os = v ? `iOS ${v[1].replace('_', '.')}` : 'iOS';
    model = `iPhone (${os})`;
  } else if (/iPad/i.test(ua)) {
    const v = ua.match(/OS (\d+[_\.]\d+)/);
    os = v ? `iPadOS ${v[1].replace('_', '.')}` : 'iPadOS';
    model = `iPad (${os})`;
  } else if (/Macintosh|Mac OS X/i.test(ua)) {
    const v = ua.match(/Mac OS X (\d+[_\.]\d+)/);
    os = v ? `macOS ${v[1].replace('_', '.')}` : 'macOS';
    model = `Mac (${os})`;
  } else if (/Android/i.test(ua)) {
    const v = ua.match(/Android (\d+(\.\d+)?)/);
    os = v ? `Android ${v[1]}` : 'Android';
    const m = ua.match(/;\s*([A-Za-z0-9\-\s\_]+)\s+Build\//);
    model = m ? `${m[1].trim()} (${os})` : `Android Device (${os})`;
  } else if (/Linux/i.test(ua)) {
    os = 'Linux';
    model = 'Linux Desktop';
  }

  let browser = 'Browser';
  if (/Edg\//i.test(ua)) browser = 'Edge';
  else if (/Chrome\//i.test(ua)) browser = 'Chrome';
  else if (/Safari\//i.test(ua) && !/Chrome/i.test(ua)) browser = 'Safari';
  else if (/Firefox\//i.test(ua)) browser = 'Firefox';

  if (model === 'Windows PC' || model === 'Linux Desktop') {
    model = `${model} (${browser})`;
  }

  return { os, model };
}

function generateRandomKey(prefix = 'HAX') {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const chunk = () => Array.from({ length: 4 }, () => chars[crypto.randomInt(0, chars.length)]).join('');
  const safePrefix = String(prefix || 'HAXT').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4) || 'HAXX';
  return `${safePrefix}-${chunk()}-${chunk()}-${chunk()}`;
}

function isAdminAuthorized(req) {
  if (!ADMIN_PASSWORD) return false;
  const auth = req.headers.authorization || '';
  const [type, encoded] = auth.split(' ');
  if (type !== 'Basic' || !encoded) return false;
  let decoded = '';
  try { decoded = Buffer.from(encoded, 'base64').toString('utf8'); } catch { return false; }
  const divider = decoded.indexOf(':');
  if (divider < 0 || decoded.slice(0, divider) !== 'admin') return false;
  const provided = decoded.slice(divider + 1);
  const expectedHash = crypto.createHash('sha256').update(ADMIN_PASSWORD).digest();
  const providedHash = crypto.createHash('sha256').update(provided).digest();
  const correct = crypto.timingSafeEqual(expectedHash, providedHash);
  const ip = req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const record = adminFailures.get(ip) || { count: 0, until: 0 };
  if (record.until > now) return false;
  if (correct) {
    adminFailures.delete(ip);
    return true;
  }
  record.count += 1;
  if (record.count >= 8) { record.count = 0; record.until = now + 15 * 60 * 1000; }
  adminFailures.set(ip, record);
  return false;
}

const server = http.createServer((req, res) => {
  handleRequest(req, res).catch(error => {
    console.error('[HAX_TEAM] Request failed:', error && error.message ? error.message : error);
    if (!res.headersSent) sendJson(res, 500, { error: 'internal server error' });
    else if (!res.writableEnded) res.destroy();
  });
});

async function handleRequest(req, res) {
  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;

  // The portal and its APIs are same-origin. Do not expose wildcard CORS.
  res.adminRoute = pathname.startsWith('/api/admin/') || pathname === '/api/config/export' || pathname === '/admin' || pathname === '/admin/' || pathname === '/admin/index.html' || pathname === '/admin/admin.js' || pathname === '/admin.js';
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
  if (req.headers['x-forwarded-proto'] === 'https') {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }

  if (pathname.startsWith('/api/admin/') || pathname === '/admin' || pathname === '/admin/' || pathname === '/admin/index.html' || pathname === '/admin/admin.js' || pathname === '/admin.js') {
    if (!ADMIN_PASSWORD) return sendJson(res, 503, { error: 'Admin password is not configured. Set ADMIN_PASSWORD in your hosting environment.' });
    if (!isAdminAuthorized(req)) {
      res.writeHead(401, { 'WWW-Authenticate': 'Basic realm=\"HAX_TEAM Admin Panel\"', 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Admin authentication required');
      return;
    }
  }

  if (res.adminRoute && ['POST', 'PATCH', 'DELETE'].includes(req.method)) {
    const origin = req.headers.origin;
    if (origin) {
      let originHost = '';
      try { originHost = new URL(origin).host; } catch {}
      if (!originHost || originHost !== req.headers.host) {
        return sendJson(res, 403, { error: 'cross-origin admin request blocked' });
      }
    }
    const hasRequestBody = Number(req.headers['content-length'] || 0) > 0 || !!req.headers['transfer-encoding'];
    if (hasRequestBody && ['POST', 'PATCH'].includes(req.method) && !/^application\/json(?:\s*;|$)/i.test(req.headers['content-type'] || '')) {
      return sendJson(res, 415, { error: 'admin API requires application/json' });
    }
  }

  if (req.method === 'OPTIONS') {
    if (res.adminRoute) { res.writeHead(403); res.end(); return; }
    res.writeHead(204);
    res.end();
    return;
  }

  // ==========================================
  // CLIENT API ENDPOINTS
  // ==========================================

  if (pathname === '/health' && req.method === 'GET') {
    return sendJson(res, 200, { ok: true, service: 'HAX_TEAM' });
  }

  // Check Maintenance Status
  if (pathname === '/api/maintenance' && req.method === 'GET') {
    return sendJson(res, 200, db.getMaintenance());
  }

  // Client Key Authentication / Redeem
  if (pathname === '/api/redeem' && req.method === 'POST') {
    const body = await readJsonBody(req, res);
    if (!body) return;
    const rawKey = String(body.key || '').trim();
    if (rawKey.length > 128) return sendJson(res, 400, { error: 'invalid license key format' });
    const key = rawKey.toUpperCase();

    if (!rawKey) {
      return sendJson(res, 400, { error: 'enter your full key' });
    }

    const ua = req.headers['user-agent'] || '';
    const serverDev = detectServerDevice(ua);
    const clientHwid = String(body.hwid || '').trim().slice(0, 128) || `HAX-${crypto.createHash('sha256').update(ua + (req.socket.remoteAddress || '')).digest('hex').slice(0, 16).toUpperCase()}`;
    const clientDeviceModel = String(body.device_model || '').trim().slice(0, 120) || serverDev.model;
    const clientDeviceOs = String(body.device_os || '').trim().slice(0, 80) || serverDev.os;

    const maintenance = db.getMaintenance();

    // Maintenance check
    if (maintenance.enabled) {
      const isAllowed = maintenance.allowed_logins.some(
        item => String(item).toUpperCase() === key
      );
      if (!isAllowed) {
        return sendJson(res, 403, { 
          error: maintenance.blocked 
            ? 'your account is paused during maintenance. back soon.' 
            : 'maintenance in progress. only allowed test logins are currently permitted.' 
        });
      }
    }

    // Check Key in Database
    let keyRecord = db.findKey(key);

    if (!keyRecord) {
      return sendJson(res, 404, { error: 'invalid license key' });
    }

    if (keyRecord.status !== 'active') {
      return sendJson(res, 403, { error: keyRecord.status === 'revoked' ? 'this license key has been revoked' : 'this license key is not active' });
    }

    if (!keyRecord.expires_at && !keyRecord.activated_at && Number.isInteger(Number(keyRecord.duration_days)) && Number(keyRecord.duration_days) > 0) {
      const activatedAt = new Date();
      const expiresAt = new Date(activatedAt.getTime() + Number(keyRecord.duration_days) * 86400000);
      db.updateKey(key, { activated_at: activatedAt.toISOString(), expires_at: expiresAt.toISOString() });
      keyRecord = db.findKey(key);
    }

    if (!isKeyActive(keyRecord)) {
      return sendJson(res, 403, { error: 'this license key has expired or has an invalid expiry date' });
    }

    // Device lock check & binding
    if (!keyRecord.bound_hwid) {
      keyRecord.bound_hwid = clientHwid;
      keyRecord.device_model = clientDeviceModel;
      keyRecord.device_os = clientDeviceOs;
      db.updateKey(key, {
        bound_hwid: clientHwid,
        device_model: clientDeviceModel,
        device_os: clientDeviceOs
      });
    } else {
      if (keyRecord.bound_hwid !== clientHwid) {
        return sendJson(res, 403, { 
          error: `key is locked to another device (${keyRecord.device_model || 'other device'}). reset device lock from the site first.` 
        });
      }
      if (clientDeviceModel && clientDeviceModel !== 'Unknown Device' && clientDeviceModel !== keyRecord.device_model) {
        keyRecord.device_model = clientDeviceModel;
        keyRecord.device_os = clientDeviceOs;
        db.updateKey(key, { device_model: clientDeviceModel, device_os: clientDeviceOs });
      }
    }

    return sendJson(res, 200, {
      ok: true,
      me: {
        status: 'active',
        bound_hwid: keyRecord.bound_hwid,
        device_model: keyRecord.device_model,
        device_os: keyRecord.device_os,
        created_at: keyRecord.created_at || null,
        activated_at: keyRecord.activated_at || null,
        expires_at: keyRecord.expires_at || null,
        features: keyRecord.features && Object.keys(keyRecord.features).length > 0 
          ? keyRecord.features 
          : db.get().global_features
      }
    });
  }

  // Features GET and PATCH
  if (pathname === '/api/features') {
    if (req.method === 'GET') {
      return sendJson(res, 200, { features: db.get().global_features });
    }
    if (req.method === 'PATCH') {
      const body = await readJsonBody(req, res);
      if (!body) return;
      const keyRecord = body.key ? db.findKey(body.key) : null;
      if (!isKeyActive(keyRecord) || (keyRecord.bound_hwid && keyRecord.bound_hwid !== String(body.hwid || '').trim())) {
        return sendJson(res, 403, { error: 'an active key on this device is required' });
      }
      if (body.features && typeof body.features === 'object') {
        db.updateKey(body.key, { features: body.features });
        return sendJson(res, 200, { ok: true, features: body.features });
      }
      return sendJson(res, 400, { error: 'feature settings are required' });
    }
  }

  // Tunnel Socket Statistics
  if (pathname === '/api/engine/tunnel-stats' && req.method === 'GET') {
    return sendJson(res, 200, gameTunnel.getStats());
  }

  // Happ Tunnel Config Generation
  if (pathname === '/api/happ' && req.method === 'POST') {
    const body = await readJsonBody(req, res);
    if (!body) return;
    const key = String(body.key || '').trim();
    const keyRecord = key ? db.findKey(key) : null;
    if (!isKeyActive(keyRecord) || (keyRecord.bound_hwid && keyRecord.bound_hwid !== String(body.hwid || '').trim())) {
      return sendJson(res, 403, { error: 'an active subscription key on this device is required' });
    }
    const nodes = db.get().nodes;

    const configData = {
      version: '1.7',
      client: 'HAX_TEAM',
      key: key,
      created_at: new Date().toISOString(),
      nodes: nodes.map(n => ({
        name: `${n.flag} ${n.name}`,
        address: n.host,
        port: n.port,
        ping: `${n.ping}ms`,
        status: n.status
      })),
      active_features: db.get().global_features,
      routing: {
        rules: [{ domain_suffix: ['freefiremobile.com', 'garena.com'], outbound: 'phantom-tunnel' }]
      }
    };

    const encoded = Buffer.from(JSON.stringify(configData)).toString('base64');
    return sendJson(res, 200, {
      ok: true,
      href: 'https://apps.apple.com/us/app/happ-proxy-utility/id6504287215',
      deepLink: `happ://import?data=${encodeURIComponent(encoded)}`,
      config: configData
    });
  }

  // Reset / Unbind HWID
  if ((pathname === '/api/unbind-hwid' || pathname === '/api/reset-hwid') && req.method === 'POST') {
    const body = await readJsonBody(req, res);
    if (!body) return;
    if (body.key) {
      const keyRecord = db.findKey(body.key);
      const providedHwid = String(body.hwid || '').trim();
      if (!isKeyActive(keyRecord) || !providedHwid || keyRecord.bound_hwid !== providedHwid) {
        return sendJson(res, 403, { error: 'the active device must authorize this reset' });
      }
      db.updateKey(body.key, { bound_hwid: null, device_model: null, device_os: null });
      return sendJson(res, 200, { ok: true, message: 'Device lock removed. Next login will bind your current device.' });
    }
    return sendJson(res, 400, { error: 'key and current device id are required' });
  }

  // Config Export Download - administrator only
  if (pathname === '/api/config/export' && req.method === 'GET') {
    if (!ADMIN_PASSWORD) return sendJson(res, 503, { error: 'Admin password is not configured.' });
    if (!isAdminAuthorized(req)) { res.writeHead(401, { 'WWW-Authenticate': 'Basic realm=\"HAX_TEAM Admin Panel\"' }); res.end('Admin authentication required'); return; }
    const nodes = db.get().nodes;
    const configData = {
      version: '1.7',
      client: 'HAX_TEAM',
      created_at: new Date().toISOString(),
      nodes: nodes,
      features: db.get().global_features
    };
    res.writeHead(200, {
      'Content-Type': 'application/json',
      'Content-Disposition': 'attachment; filename="phantom-happ-config.json"'
    });
    res.end(JSON.stringify(configData, null, 2));
    return;
  }

  // Logout
  if (pathname === '/api/logout' && req.method === 'POST') {
    return sendJson(res, 200, { ok: true });
  }

  // Real-time Event Stream (SSE)
  if (pathname === '/api/events') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive'
    });
    res.write('event: connected\ndata: {}\n\n');
    sseClients.add(res);

    req.on('close', () => {
      sseClients.delete(res);
    });
    return;
  }

  // ==========================================
  // ADMIN API - all routes above are protected by HTTP Basic Auth
  // ==========================================
  if (pathname === '/api/admin/overview' && req.method === 'GET') {
    const data = db.get();
    const totalKeys = data.keys.length;
    const activeKeys = data.keys.filter(k => k.status === 'active' && (!k.expires_at || Date.parse(k.expires_at) > Date.now())).length;
    const unboundKeys = data.keys.filter(k => !k.bound_hwid).length;
    const expiredKeys = data.keys.filter(k => k.expires_at && Date.parse(k.expires_at) <= Date.now()).length;
    const revokedKeys = data.keys.filter(k => k.status === 'revoked').length;
    const totalUsers = data.nodes.reduce((acc, n) => acc + (n.users || 0), 0);
    return sendJson(res, 200, { totalKeys, activeKeys, unboundKeys, expiredKeys, revokedKeys, totalUsers, maintenance: data.maintenance, nodes: data.nodes });
  }

  if (pathname === '/api/admin/keys' && req.method === 'GET') {
    return sendJson(res, 200, { keys: db.get().keys });
  }

  if (pathname === '/api/admin/keys/generate' && req.method === 'POST') {
    const body = await readJsonBody(req, res);
    if (!body) return;
    const count = Math.min(Math.max(parseInt(body.count, 10) || 1, 1), 50);
    const durationDays = Math.min(Math.max(parseInt(body.days, 10) || 30, 1), 3650);
    const note = String(body.note || 'Generated from HAX_TEAM Admin Panel').slice(0, 120);
    const prefix = String(body.prefix || 'HAXT').trim().toUpperCase();
    const createdKeys = [];
    for (let i = 0; i < count; i++) {
      let newKeyStr;
      do { newKeyStr = generateRandomKey(prefix); } while (db.findKey(newKeyStr));
      const createdAt = new Date().toISOString();
      const newKeyObj = {
        key: newKeyStr, status: 'active', bound_hwid: null, device_model: null, device_os: null,
        created_at: createdAt, activated_at: null, expires_at: null, duration_days: durationDays,
        note, features: db.get().global_features
      };
      db.addKey(newKeyObj);
      createdKeys.push(newKeyObj);
    }
    return sendJson(res, 200, { ok: true, keys: createdKeys });
  }

  const keyActionMatch = pathname.match(/^\/api\/admin\/keys\/([^/]+)\/(unbind|toggle-status|extend)$/);
  if (keyActionMatch && req.method === 'POST') {
    const targetKey = decodeURIComponent(keyActionMatch[1]);
    const action = keyActionMatch[2];
    const keyObj = db.findKey(targetKey);
    if (!keyObj) return sendJson(res, 404, { error: 'key not found' });
    if (action === 'unbind') {
      db.updateKey(targetKey, { bound_hwid: null, device_model: null, device_os: null });
      return sendJson(res, 200, { ok: true, message: 'device unbound' });
    }
    if (action === 'toggle-status') {
      const newStatus = keyObj.status === 'active' ? 'revoked' : 'active';
      db.updateKey(targetKey, { status: newStatus });
      if (newStatus === 'revoked') broadcastEvent('logout', { key: targetKey });
      return sendJson(res, 200, { ok: true, status: newStatus });
    }
    if (action === 'extend') {
      const body = await readJsonBody(req, res);
      if (!body) return;
      const addDays = Math.min(Math.max(parseInt(body.days, 10) || 30, 1), 3650);
      const currentExpiry = keyObj.expires_at ? Date.parse(keyObj.expires_at) : Date.now();
      const base = Number.isFinite(currentExpiry) && currentExpiry > Date.now() ? currentExpiry : Date.now();
      const newExpiry = new Date(base + addDays * 86400000).toISOString();
      db.updateKey(targetKey, { expires_at: newExpiry, status: 'active' });
      return sendJson(res, 200, { ok: true, expires_at: newExpiry });
    }
  }

  const deleteKeyMatch = pathname.match(/^\/api\/admin\/keys\/([^/]+)$/);
  if (deleteKeyMatch && req.method === 'DELETE') {
    const targetKey = decodeURIComponent(deleteKeyMatch[1]);
    db.deleteKey(targetKey);
    broadcastEvent('logout', { key: targetKey });
    return sendJson(res, 200, { ok: true });
  }

  if (pathname === '/api/admin/maintenance' && req.method === 'POST') {
    const body = await readJsonBody(req, res);
    if (!body) return;
    const updated = db.setMaintenance({
      enabled: typeof body.enabled === 'boolean' ? body.enabled : false,
      blocked: typeof body.blocked === 'boolean' ? body.blocked : false,
      allowed_logins: Array.isArray(body.allowed_logins) ? body.allowed_logins : (body.allowed_logins || '').split(',').map(v => v.trim()).filter(Boolean),
      title: String(body.title || 'maintenance').slice(0, 100),
      message: String(body.message || 'Maintenance in progress.').slice(0, 500)
    });
    broadcastEvent('maintenance', updated.maintenance);
    return sendJson(res, 200, { ok: true, maintenance: updated.maintenance });
  }

  // ==========================================
  // STATIC ASSET & PAGE ROUTING
  // ==========================================
  if (pathname.startsWith('/api/')) return sendJson(res, 404, { error: 'API route not found' });
  let filePath;

  if (pathname === '/admin' || pathname === '/admin/' || pathname === '/admin/index.html') {
    filePath = path.join(ROOT_DIR, 'public', 'admin.html');
  } else if (pathname === '/admin/admin.js' || pathname === '/admin.js') {
    filePath = path.join(ROOT_DIR, 'public', 'admin.js');
  } else if (pathname === '/' || pathname === '/index.html') {
    filePath = path.join(ROOT_DIR, 'index.html');
  } else if (pathname.startsWith('/src/')) {
    filePath = path.join(ROOT_DIR, pathname);
  } else {
    const cleanPath = pathname.startsWith('/') ? pathname.slice(1) : pathname;
    const pubPath = path.join(ROOT_DIR, 'public', cleanPath);
    const rootPath = path.join(ROOT_DIR, cleanPath);
    
    if (cleanPath === '' || cleanPath === 'index.html') {
      filePath = path.join(ROOT_DIR, 'index.html');
    } else if (fs.existsSync(pubPath)) {
      filePath = pubPath;
    } else if (fs.existsSync(rootPath)) {
      filePath = rootPath;
    } else {
      filePath = path.join(ROOT_DIR, 'index.html');
    }
  }

  let normalizedRequestPath = pathname;
  try { normalizedRequestPath = decodeURIComponent(pathname); } catch {
    res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Bad Request'); return;
  }
  normalizedRequestPath = normalizedRequestPath.replace(/\\/g, '/');
  const resolvedFilePath = path.resolve(filePath);
  const rootPrefix = path.resolve(ROOT_DIR) + path.sep;
  const sensitivePaths = [
    path.resolve(ROOT_DIR, 'server.js'), path.resolve(ROOT_DIR, 'package.json'), path.resolve(ROOT_DIR, 'README.md'),
    path.resolve(ROOT_DIR, 'data'), path.resolve(ROOT_DIR, '.github'), path.resolve(ROOT_DIR, 'src/engine')
  ];
  const directAdminAsset = normalizedRequestPath === '/public/admin.html' || normalizedRequestPath === '/public/admin.js';
  const blockedStatic = directAdminAsset || sensitivePaths.some(sensitive => resolvedFilePath === sensitive || resolvedFilePath.startsWith(sensitive + path.sep));
  if (blockedStatic || (resolvedFilePath !== path.resolve(ROOT_DIR) && !resolvedFilePath.startsWith(rootPrefix))) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('404 Not Found');
    return;
  }

  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('404 Not Found');
      } else {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('500 Internal Server Error');
      }
    } else {
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content);
    }
  });
}

server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n==============================================`);
  console.log(`🚀 HAX_TEAM Core System running on:`);
  console.log(`👉 Client Portal: http://localhost:${PORT}/`);
  console.log(`👉 Admin Panel:   http://localhost:${PORT}/admin`);
  console.log(`==============================================\n`);
});
