const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const port = 32000 + Math.floor(Math.random() * 20000);
const tunnelPort = 52000 + Math.floor(Math.random() * 10000);
const baseUrl = `http://127.0.0.1:${port}`;
const adminPassword = 'local-test-admin-secret';
const adminAuth = `Basic ${Buffer.from(`admin:${adminPassword}`).toString('base64')}`;
let tempDir;
let serverProcess;

async function waitForServer() {
  const deadline = Date.now() + 12000;
  while (Date.now() < deadline) {
    try {
      const response = await fetch(`${baseUrl}/health`);
      if (response.ok) return;
    } catch {}
    await new Promise(resolve => setTimeout(resolve, 150));
  }
  throw new Error('server did not become healthy in time');
}

async function api(pathname, options = {}) {
  return fetch(`${baseUrl}${pathname}`, {
    ...options,
    headers: {
      ...(options.headers || {}),
      ...(options.admin ? { Authorization: adminAuth, Origin: baseUrl } : {})
    }
  });
}

before(async () => {
  tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'hax-team-test-'));
  serverProcess = spawn(process.execPath, ['server.js'], {
    cwd: root,
    env: {
      ...process.env,
      PORT: String(port),
      HAX_TUNNEL_PORT: String(tunnelPort),
      HAX_DATA_DIR: tempDir,
      ADMIN_PASSWORD: adminPassword,
      NODE_ENV: 'test'
    },
    stdio: ['ignore', 'ignore', 'pipe']
  });
  await waitForServer();
});

after(() => {
  if (serverProcess && !serverProcess.killed) serverProcess.kill('SIGTERM');
  if (tempDir) fs.rmSync(tempDir, { recursive: true, force: true });
});

test('public health and private files', async () => {
  const health = await api('/health');
  assert.equal(health.status, 200);
  assert.equal((await api('/server.js')).status, 404);
  assert.equal((await api('/data/database.json')).status, 404);
});

test('admin panel requires authentication', async () => {
  assert.equal((await api('/admin')).status, 401);
  assert.equal((await api('/admin', { headers: { Authorization: adminAuth } })).status, 200);
});

test('admin-created key validates, binds to one device, and stops after revocation', async () => {
  const create = await api('/api/admin/keys/generate', {
    method: 'POST',
    admin: true,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prefix: 'PWUP', days: 2, count: 1, note: 'API test' })
  });
  assert.equal(create.status, 200);
  const createdData = await create.json();
  const keyRecord = createdData.keys[0];
  assert.ok(keyRecord);
  assert.equal(keyRecord.expires_at, null);
  assert.equal(keyRecord.duration_days, 2);

  const redeem = await api('/api/redeem', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ key: keyRecord.key, hwid: 'device-a', device_model: 'Test Device', device_os: 'Test OS' })
  });
  assert.equal(redeem.status, 200);
  const redeemData = await redeem.json();
  assert.ok(Date.parse(redeemData.me.expires_at) > Date.now());
  assert.ok(redeemData.me.activated_at);

  const wrongDevice = await api('/api/redeem', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ key: keyRecord.key, hwid: 'device-b' })
  });
  assert.equal(wrongDevice.status, 403);

  const revoke = await api(`/api/admin/keys/${encodeURIComponent(keyRecord.key)}/toggle-status`, {
    method: 'POST', admin: true
  });
  assert.equal(revoke.status, 200);

  const rejected = await api('/api/redeem', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ key: keyRecord.key, hwid: 'device-a' })
  });
  assert.equal(rejected.status, 403);
});

test('admin mutation rejects cross-origin requests', async () => {
  const response = await fetch(`${baseUrl}/api/admin/keys/generate`, {
    method: 'POST',
    headers: {
      Authorization: adminAuth,
      Origin: 'https://attacker.invalid',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ prefix: 'PWUP', days: 1, count: 1 })
  });
  assert.equal(response.status, 403);
});


test('expired keys are denied and admin extension restores access', async () => {
  const create = await api('/api/admin/keys/generate', {
    method: 'POST',
    admin: true,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prefix: 'TIME', days: 1, count: 1, note: 'expiry test' })
  });
  assert.equal(create.status, 200);
  const { keys } = await create.json();
  const key = keys[0].key;

  const first = await api('/api/redeem', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ key, hwid: 'expiry-device' })
  });
  assert.equal(first.status, 200);

  const databasePath = path.join(tempDir, 'database.json');
  const database = JSON.parse(fs.readFileSync(databasePath, 'utf8'));
  const record = database.keys.find(item => item.key === key);
  record.expires_at = new Date(Date.now() - 60_000).toISOString();
  fs.writeFileSync(databasePath, JSON.stringify(database, null, 2));

  const expired = await api('/api/redeem', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ key, hwid: 'expiry-device' })
  });
  assert.equal(expired.status, 403);

  const extend = await api(`/api/admin/keys/${encodeURIComponent(key)}/extend`, {
    method: 'POST', admin: true,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ days: 3 })
  });
  assert.equal(extend.status, 200);

  const restored = await api('/api/redeem', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ key, hwid: 'expiry-device' })
  });
  assert.equal(restored.status, 200);
});
