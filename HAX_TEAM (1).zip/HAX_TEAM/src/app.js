import { CONFIG } from './config.js';
import { TRANSLATIONS } from './translations.js';
import { Icons } from './icons.js';

let countdownTimer = null;
let sessionCheckTimer = null;
let pendingSavedSession = null;

const state = {
  lang: localStorage.getItem('powerup_lang') || 'en',
  tab: 'status',
  isConnected: localStorage.getItem('powerup_vpn_connected') === 'true',
  auth: {
    loggedIn: false,
    key: '',
    me: {
      status: 'active',
      bound_hwid: null,
      device_model: null,
      device_os: null,
      expires_at: null,
      features: JSON.parse(JSON.stringify(CONFIG.DEFAULT_FEATURES))
    }
  }
};

// A cached key is only a hint. Never trust cached localStorage session data
// without asking the server again before showing the protected dashboard.
const savedSession = localStorage.getItem('powerup_session');
if (savedSession) {
  try {
    const parsed = JSON.parse(savedSession);
    if (parsed && typeof parsed.key === 'string' && parsed.key.trim()) {
      pendingSavedSession = parsed;
      state.auth.key = parsed.key.trim();
    }
  } catch (e) {
    localStorage.removeItem('powerup_session');
  }
}

function tr(en, ar) { return state.lang === 'ar' ? ar : en; }

function formatCountdown(targetIso) {
  if (!targetIso) return tr('NO EXPIRY', 'بدون انتهاء');
  const diff = new Date(targetIso).getTime() - Date.now();
  if (!Number.isFinite(diff)) return '—';
  if (diff <= 0) return tr('EXPIRED', 'منتهي');
  const sec = Math.floor(diff / 1000);
  const days = Math.floor(sec / 86400);
  const hours = Math.floor((sec % 86400) / 3600);
  const mins = Math.floor((sec % 3600) / 60);
  if (days > 0) return `${days}D ${hours}H`;
  if (hours > 0) return `${hours}H ${mins}M`;
  return `${mins}M`;
}


function getExpiryProgress(me) {
  const end = Date.parse(me?.expires_at || '');
  if (!Number.isFinite(end)) return 100;
  const start = Date.parse(me?.activated_at || me?.created_at || '');
  if (!Number.isFinite(start) || end <= start) return end > Date.now() ? 100 : 0;
  return Math.max(0, Math.min(100, ((end - Date.now()) / (end - start)) * 100));
}

function renderDashboard() {
  const root = document.getElementById('app');
  if (!root) return;

  const isRtl = state.lang === 'ar';
  document.documentElement.setAttribute('lang', state.lang);
  document.documentElement.setAttribute('dir', isRtl ? 'rtl' : 'ltr');
  document.title = 'HAX_TEAM — Client Portal';

  const statusColor = state.isConnected ? '#22c55e' : '#71717a';
  const statusText = state.isConnected ? tr('ONLINE', 'متصل') : tr('OFFLINE', 'غير متصل');

  root.innerHTML = `
    <div class="client-shell" style="background-color: #050505; color: #cacaca; min-height: 100vh; width: 100%; display: flex; flex-direction: column; justify-content: space-between; align-items: center; padding: 20px 16px 110px 16px; box-sizing: border-box; font-family: 'JetBrains Mono', monospace, sans-serif;">
      
      <!-- الشريط العلوي للحالة -->
      <div style="width: 100%; max-width: 400px; display: flex; justify-content: space-between; align-items: center; padding: 10px 4px;">
        <div style="display: flex; align-items: center; gap: 8px; font-size: 11px; font-weight: 800; letter-spacing: 2px; color: ${statusColor};">
          <span style="height: 8px; width: 8px; background-color: ${statusColor}; box-shadow: 0 0 8px ${statusColor};"></span>
          ${statusText}
        </div>
        
        <div style="display:flex;align-items:center;gap:8px;">
          <a href="/admin" target="_blank" rel="noopener" style="background:linear-gradient(135deg,#7d091b,#e51d39);border:1px solid #ff465d;border-radius:8px;padding:7px 10px;color:#fff;text-decoration:none;font-size:10px;font-weight:800;box-shadow:0 0 16px #a10d293d;">${tr('ADMIN', 'الإدارة')}</a>
          <button id="lang-toggle-icon" style="background: #0c0c0e; border: 1px solid #1a1a1e; border-radius: 8px; padding: 7px 10px; color: #cccccc; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 11px; font-weight: 700;">
            ${state.lang.toUpperCase()}
          </button>
        </div>
      </div>

      <!-- محتوى التبويبات -->
      <div style="width: 100%; max-width: 400px; margin: auto 0; display: flex; flex-direction: column; align-items: center;">
        ${state.tab === 'status' ? renderStatusTab(state.auth.me) : ''}
        ${state.tab === 'manage' ? renderManageTab() : ''}
      </div>

      <!-- شريط التنقل السفلي -->
      ${renderBottomNav()}
    </div>
  `;
  attachDashboardEvents();
  syncCountdownTicker();
}

function syncCountdownTicker() {
  if (countdownTimer) clearInterval(countdownTimer);
  if (sessionCheckTimer) clearInterval(sessionCheckTimer);
  countdownTimer = null;
  sessionCheckTimer = null;
  if (!state.auth.loggedIn) return;

  if (state.tab === 'status') {
    countdownTimer = setInterval(() => {
      const me = state.auth.me || {};
      const expiry = me.expires_at ? Date.parse(me.expires_at) : Infinity;
      if (Number.isFinite(expiry) && expiry <= Date.now()) {
        logout(true);
        return;
      }
      const timeNode = document.querySelector('.expiry-time');
      const gear = document.querySelector('.expiry-gear');
      if (timeNode) timeNode.textContent = formatCountdown(me.expires_at);
      if (gear) gear.style.setProperty('--expiry-progress', `${getExpiryProgress(me)}%`);
    }, 1000);
  }

  // Keep checking the authoritative server even while the user is on another tab.
  sessionCheckTimer = setInterval(async () => {
    const result = await verifyServerSession();
    if (result === false) logout(true);
    const happButton = document.getElementById('happ-btn');
    if (happButton) happButton.disabled = result !== true;
  }, 30000);
}
async function verifyServerSession() {
  if (!state.auth.key) return false;
  try {
    const dev = await getRealClientDevice();
    const res = await fetch(CONFIG.AUTH_API_URL, {
      method: 'POST',
      cache: 'no-store',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: state.auth.key, hwid: dev.hwid, device_model: dev.device_model, device_os: dev.device_os })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.ok || !data.me) return false;
    state.auth.me = { ...state.auth.me, ...data.me };
    localStorage.setItem('powerup_session', JSON.stringify({ key: state.auth.key, me: state.auth.me }));
    return true;
  } catch (error) {
    console.warn('Session revalidation failed:', error);
    return null;
  }
}

function renderStatusTab(me) {
  const expiresText = formatCountdown(me.expires_at);
  const progress = getExpiryProgress(me);
  const expired = expiresText === 'EXPIRED' || expiresText === 'منتهي';

  return `
    <div style="width: 100%; display: flex; flex-direction: column; align-items: center; gap: 16px; text-align: center;">
      <div style="width: 100%; display: flex; justify-content: space-between; align-items: center; font-size: 10px; color: #9a8b90; padding: 0 4px; letter-spacing: 1px;">
        <span>${tr('HOME', 'الرئيسية')}</span>
        <span>${tr('SUBSCRIPTION STATUS', 'حالة الاشتراك')}</span>
      </div>

      <div class="expiry-stage">
        <div class="expiry-gear" style="--expiry-progress:${progress}%;" aria-label="${tr('Subscription time remaining', 'الوقت المتبقي للاشتراك')}">
          <div class="expiry-core">
            <img src="logo.png" alt="HAX_TEAM" class="expiry-logo" onerror="this.onerror=null;this.style.display='none';" />
            <div class="expiry-time" style="color:${expired ? '#ff697a' : '#ffffff'};">${expiresText}</div>
            <div class="expiry-caption">${tr('TIME LEFT', 'الوقت المتبقي')}</div>
          </div>
        </div>
        <div class="expiry-glow"></div>
      </div>

      <div style="width: 100%; background: #0c0c0e; border: 1px solid #45121d; border-radius: 14px; padding: 14px 18px; display: flex; justify-content: space-between; align-items: center; box-sizing: border-box;">
        <div style="display: flex; align-items: center; gap: 10px; min-width:0;">
          <span style="font-size: 10px; color: #a89aa0;">${tr('KEY', 'المفتاح')}</span>
          <span style="font-size: 12px; font-weight: 700; letter-spacing: .7px; color: #ffffff;overflow-wrap:anywhere;">${state.auth.key || 'PWUP-XXXX-XXXX-XXXX'}</span>
        </div>
        <button id="copy-key-btn" style="background: #251016; border: 1px solid #5c1725; border-radius: 8px; color: #ffffff; padding: 8px 12px; font-size: 10px; font-weight: 700; cursor: pointer;">${tr('COPY', 'نسخ')}</button>
      </div>

      <div style="width: 100%;">
        <button id="happ-btn" ${expired ? 'disabled' : ''} style="width: 100%; background: #e50914; color: #ffffff; border: none; border-radius: 14px; padding: 16px; display: flex; justify-content: space-between; align-items: center; cursor: ${expired ? 'not-allowed' : 'pointer'}; opacity:${expired ? '.45' : '1'}; box-shadow: 0 8px 24px rgba(229, 9, 20, 0.3);">
          <div style="text-align: ${state.lang === 'ar' ? 'right' : 'left'};">
            <div style="font-family: 'Anton', sans-serif; font-size: 20px; letter-spacing: 1px;">${tr('ADD SUBSCRIPTION', 'إضافة الاشتراك')}</div>
            <div style="font-size: 10.5px; color: #ffd0d5; font-family: 'Inter', sans-serif; font-weight: 600;">${tr('Open this subscription in Happ', 'افتح هذا الاشتراك في Happ')}</div>
          </div>
          <div style="background: #8d0a1c; width: 36px; height: 36px; display: grid; place-items: center; border-radius: 8px; font-size: 22px; font-weight: bold; color: #fff;">+</div>
        </button>
      </div>
    </div>
  `;
}

function renderFeaturesTab(me) {
  const f = me.features || {};
  
  // التأكد من أن POWER هو الخيار الافتراضي دائماً
  if (!f.marker) {
    f.marker = { enabled: true, type: 'POWER' };
  } else if (!f.marker.type || f.marker.type === 'PHANTOM') {
    f.marker.type = 'POWER';
  }

  const marker = f.marker;
  const aimpoint = f.aimpoint || { enabled: false };
  const aimLag = f.aimLag || { enabled: false };

  // إزالة PHANTOM من القائمة
  const markerTypes = ['POWER', 'DREAM', 'ICE WALL', 'MOCO', 'CLU', 'SHIROU', 'IRIS'];

  return `
    <div style="width: 100%; display: flex; flex-direction: column; gap: 12px; text-align: left; max-height: 70vh; overflow-y: auto;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
        <span style="font-family: 'Anton', sans-serif; font-size: 32px; letter-spacing: 1px; color: #ffffff;">FEATURES</span>
        <span style="font-family: 'Anton', sans-serif; font-size: 20px; color: #e50914;">3/3</span>
      </div>
      <p style="font-size: 11.5px; color: #71717a; margin-bottom: 10px;">changes apply from your next match</p>

      <!-- ميزة Marker -->
      <div style="background: #0c0c0e; border: 1px solid #1a1a1e; border-radius: 16px; padding: 16px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 12px; color: #71717a; font-weight: bold;">01</span>
            <span style="font-family: 'Anton', sans-serif; font-size: 22px; letter-spacing: 1px; color: #ffffff;">MARKER</span>
            <span style="background: rgba(229,9,20,0.2); color: #e50914; font-size: 9px; font-weight: 800; padding: 2px 6px; border-radius: 4px;">RISK</span>
          </div>
          <button type="button" data-toggle="marker" style="width: 44px; height: 24px; border-radius: 12px; background: ${marker.enabled ? '#e50914' : '#1a1a1e'}; border: none; position: relative; cursor: pointer;">
            <span style="width: 18px; height: 18px; border-radius: 50%; background: #ffffff; position: absolute; top: 3px; ${marker.enabled ? 'right: 3px;' : 'left: 3px;'}"></span>
          </button>
        </div>
        <p style="font-size: 11px; color: #71717a; margin-bottom: 12px;">marks every enemy on your screen.</p>
        
        <div style="font-size: 10px; color: #52525b; letter-spacing: 1px; margin-bottom: 8px; font-weight: bold;">MARK STYLE</div>
        
        <!-- شبكة الأشكال مع التأثير الشفاف عند الإيقاف -->
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; position: relative; transition: all 0.3s ease; ${!marker.enabled ? 'opacity: 0.35; pointer-events: none; filter: grayscale(1);' : ''}">
          ${markerTypes.map(type => `
            <button data-marker-type="${type}" style="border: 1px solid #1a1a1e; border-radius: 8px; padding: 8px 4px; font-size: 10px; font-weight: bold; cursor: pointer; background: ${marker.type === type ? '#e50914' : '#141418'}; color: ${marker.type === type ? '#ffffff' : '#71717a'}; transition: all 0.2s;">${type}</button>
          `).join('')}
        </div>
      </div>

      <!-- ميزة Aimpoint -->
      <div style="background: #0c0c0e; border: 1px solid #1a1a1e; border-radius: 16px; padding: 16px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 12px; color: #71717a; font-weight: bold;">02</span>
            <span style="font-family: 'Anton', sans-serif; font-size: 22px; letter-spacing: 1px; color: #ffffff;">AIMPOINT</span>
            <span style="background: #222226; color: #ffffff; font-size: 9px; font-weight: 800; padding: 2px 6px; border-radius: 4px;">NEW</span>
          </div>
          <button type="button" data-toggle="aimpoint" style="width: 44px; height: 24px; border-radius: 12px; background: ${aimpoint.enabled ? '#e50914' : '#1a1a1e'}; border: none; position: relative; cursor: pointer;">
            <span style="width: 18px; height: 18px; border-radius: 50%; background: #ffffff; position: absolute; top: 3px; ${aimpoint.enabled ? 'right: 3px;' : 'left: 3px;'}"></span>
          </button>
        </div>
        <p style="font-size: 11px; color: #71717a;">moves your aim from the chest to the neck, so body shots land as headshots.</p>
      </div>

      <!-- ميزة Aim Lag -->
      <div style="background: #0c0c0e; border: 1px solid #1a1a1e; border-radius: 16px; padding: 16px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 12px; color: #71717a; font-weight: bold;">03</span>
            <span style="font-family: 'Anton', sans-serif; font-size: 22px; letter-spacing: 1px; color: #ffffff;">AIM LAG</span>
          </div>
          <button type="button" data-toggle="aimLag" style="width: 44px; height: 24px; border-radius: 12px; background: ${aimLag.enabled ? '#e50914' : '#1a1a1e'}; border: none; position: relative; cursor: pointer;">
            <span style="width: 18px; height: 18px; border-radius: 50%; background: #ffffff; position: absolute; top: 3px; ${aimLag.enabled ? 'right: 3px;' : 'left: 3px;'}"></span>
          </button>
        </div>
        <p style="font-size: 11px; color: #71717a;">freezes the enemy for a moment while you fire or scope, so they're easier to hit.</p>
      </div>
    </div>
  `;
}

function renderManageTab() {
  const discordUrl = CONFIG.SOCIAL_DISCORD_URL || 'https://discord.gg/Km6Hsxk7Y4';
  const googlePlayUrl = CONFIG.HAPP_ANDROID_URL || 'https://play.google.com/store/apps/details?id=com.happ.proxy';
  const appStoreUrl = CONFIG.HAPP_IOS_URL || 'https://apps.apple.com/app/happ-proxy-utility/id6504287215';

  return `
    <div style="width: 100%; display: flex; flex-direction: column; gap: 14px; text-align: left; max-height: 70vh; overflow-y: auto;">
      <h1 style="font-family: 'Anton', sans-serif; font-size: 32px; letter-spacing: 1px; color: #ffffff; margin-bottom: 4px;">${tr('MANAGE', 'الإدارة')}</h1>
      
      <!-- Device Lock Card -->
      <div style="background: #0c0c0e; border: 1px solid #1a1a1e; border-radius: 16px; padding: 18px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
          <span style="font-size: 10px; color: #71717a; letter-spacing: 1px;">${tr('THIS DEVICE', 'هذا الجهاز')}</span>
          <span style="background: #222226; color: #ffffff; font-size: 9px; font-weight: 700; padding: 4px 8px; border-radius: 4px;">${tr('LOCKED TO THIS KEY', 'مرتبط بهذا المفتاح')}</span>
        </div>
        <div style="font-family: 'Anton', sans-serif; font-size: 32px; color: #ffffff; margin-bottom: 2px;">HAX_TEAM</div>
        <div style="font-size: 12px; color: #71717a; margin-bottom: 8px;">${tr('Android Device', 'جهاز أندرويد')}</div>
        <div style="font-size: 10.5px; color: #3f3f46; word-break: break-all; margin-bottom: 16px;">HWID: PWUP-DEV-ACTIVE</div>

        <button id="unbind-hwid-btn" style="width: 100%; background: #141418; border: 1px solid #52202b; color: #c5a4ab; padding: 14px; font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 700; letter-spacing: 1px; cursor: pointer; border-radius: 10px;">
          ${tr('RESET DEVICE LOCK (UNBIND)', 'إلغاء ربط الجهاز')}
        </button>
      </div>

      <!-- Links & Community -->
      <div style="display: flex; flex-direction: column; gap: 8px;">
        <a href="${discordUrl}" target="_blank" style="background: #0c0c0e; border: 1px solid #1a1a1e; border-radius: 14px; padding: 14px 16px; color: #5865F2; font-size: 11.5px; font-weight: 700; text-decoration: none; display: flex; justify-content: space-between; align-items: center;">
          <span>${tr('Discord Community', 'مجتمع ديسكورد')}</span>
          <span>↗</span>
        </a>
        <a href="${googlePlayUrl}" target="_blank" style="background: #0c0c0e; border: 1px solid #1a1a1e; border-radius: 14px; padding: 14px 16px; color: #22c55e; font-size: 11.5px; font-weight: 700; text-decoration: none; display: flex; justify-content: space-between; align-items: center;">
          <span>${tr('Happ VPN (Google Play)', 'Happ على Google Play')}</span>
          <span>↗</span>
        </a>
        <a href="${appStoreUrl}" target="_blank" style="background: #0c0c0e; border: 1px solid #1a1a1e; border-radius: 14px; padding: 14px 16px; color: #ffffff; font-size: 11.5px; font-weight: 700; text-decoration: none; display: flex; justify-content: space-between; align-items: center;">
          <span>${tr('Happ VPN (App Store)', 'Happ على App Store')}</span>
          <span>↗</span>
        </a>
      </div>
      
      <!-- Logout Button -->
      <div style="margin-top: 6px;">
        <button id="logout-btn" style="width: 100%; background: transparent; border: 1px solid #e50914; color: #ff5268; padding: 14px; font-family: 'JetBrains Mono', monospace; font-size: 11px; font-weight: 800; cursor: pointer; border-radius: 12px;">
          ${tr('LOG OUT SESSION', 'تسجيل الخروج')}
        </button>
      </div>
    </div>
  `;
}

function renderBottomNav() {
  const tabs = [
    { id: 'status', label: tr('HOME', 'الرئيسية'), icon: Icons.skull(18) },
    { id: 'manage', label: tr('MANAGE', 'إدارة'), icon: Icons.settings(18) }
  ];

  return `
    <div style="position: fixed; bottom: 16px; left: 0; right: 0; display: flex; justify-content: center; z-index: 50; pointer-events: none;">
      <div style="pointer-events: auto; background: rgba(12, 12, 14, 0.95); border: 1px solid #1a1a1e; border-radius: 20px; padding: 6px; display: flex; gap: 6px; backdrop-filter: blur(12px); box-shadow: 0 10px 30px rgba(0,0,0,0.8);">
        ${tabs.map(item => `
          <button data-nav-tab="${item.id}" style="width: 86px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 4px; border-radius: 14px; padding: 8px 0; border: none; background: ${state.tab === item.id ? '#e50914' : 'transparent'}; color: ${state.tab === item.id ? '#ffffff' : '#71717a'}; cursor: pointer; transition: 0.2s;">
            ${item.icon}
            <span style="font-size: 9px; font-weight: 800; letter-spacing: 1px; text-transform: uppercase;">${item.label}</span>
          </button>
        `).join('')}
      </div>
    </div>
  `;
}

function attachDashboardEvents() {
  const langBtn = document.getElementById('lang-toggle-icon');
  if (langBtn) {
    langBtn.addEventListener('click', () => {
      state.lang = state.lang === 'en' ? 'ar' : 'en';
      localStorage.setItem('powerup_lang', state.lang);
      renderDashboard();
    });
  }

  const copyBtn = document.getElementById('copy-key-btn');
  if (copyBtn) {
    copyBtn.addEventListener('click', () => {
      navigator.clipboard.writeText(state.auth.key);
      alert('KEY COPIED TO CLIPBOARD');
    });
  }

  const happBtn = document.getElementById('happ-btn');
  if (happBtn) {
    happBtn.addEventListener('click', async () => {
      const subscriptionUrl = CONFIG.HAPP_SUBSCRIPTION_URL;
      if (!subscriptionUrl || !subscriptionUrl.startsWith('happ://')) {
        alert(tr('The Happ subscription link is not configured.', 'رابط اشتراك Happ غير مضبوط.'));
        return;
      }
      happBtn.disabled = true;
      try {
        const valid = await verifyServerSession();
        if (valid !== true) {
          if (valid === false) logout(true);
          else alert(tr('Could not contact the license server. Try again when online.', 'تعذر الاتصال بسيرفر التحقق. حاول مجدداً عند توفر الإنترنت.'));
          return;
        }
        // Open the exact URI supplied by the owner. Its encoded payload is untouched.
        window.location.href = subscriptionUrl;
      } finally {
        if (document.getElementById('happ-btn') && state.auth.loggedIn) {
          document.getElementById('happ-btn').disabled = false;
        }
      }
    });
  }

  document.querySelectorAll('[data-nav-tab]').forEach(btn => {
    btn.addEventListener('click', () => {
      state.tab = btn.getAttribute('data-nav-tab');
      renderDashboard();
    });
  });

  document.querySelectorAll('[data-toggle]').forEach(btn => {
    btn.addEventListener('click', () => {
      const field = btn.getAttribute('data-toggle');
      if (!state.auth.me.features) state.auth.me.features = {};
      const f = state.auth.me.features;
      
      if (field === 'marker') f.marker = { ...f.marker, enabled: !f.marker?.enabled };
      else if (field === 'aimpoint') f.aimpoint = { ...f.aimpoint, enabled: !f.aimpoint?.enabled };
      else if (field === 'aimLag') f.aimLag = { ...f.aimLag, enabled: !f.aimLag?.enabled };
      
      renderDashboard();
      saveFeatures(f);
    });
  });

  document.querySelectorAll('[data-marker-type]').forEach(btn => {
    btn.addEventListener('click', () => {
      if (!state.auth.me.features) state.auth.me.features = {};
      if (!state.auth.me.features.marker) state.auth.me.features.marker = {};
      state.auth.me.features.marker.type = btn.getAttribute('data-marker-type');
      renderDashboard();
      saveFeatures(state.auth.me.features);
    });
  });

  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', logout);
  }
}

async function saveFeatures(f) {
  localStorage.setItem('powerup_session', JSON.stringify({ key: state.auth.key, me: state.auth.me, features: f }));
  try {
    await fetch('/api/features', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ features: f, key: state.auth.key, hwid: (await getRealClientDevice()).hwid }) });
  } catch (e) {}
}

function logout(showExpiredMessage = false) {
  if (countdownTimer) clearInterval(countdownTimer);
  if (sessionCheckTimer) clearInterval(sessionCheckTimer);
  countdownTimer = null;
  sessionCheckTimer = null;
  localStorage.removeItem('powerup_session');
  localStorage.removeItem('powerup_vpn_connected');
  if (showExpiredMessage) alert(tr('Your key is expired, revoked, or no longer valid.', 'انتهت صلاحية مفتاحك أو تم إلغاؤه أو لم يعد صالحاً.'));
  state.auth.loggedIn = false;
  state.isConnected = false;
  state.auth.key = '';
  location.reload();
}

function updateLoginLanguage() {
  const ar = state.lang === 'ar';
  document.documentElement.lang = state.lang;
  document.documentElement.dir = ar ? 'rtl' : 'ltr';
  const set = (selector, value) => { const el = document.querySelector(selector); if (el) el.textContent = value; };
  set('.login-title', 'HAX_TEAM');
  set('.login-sub', ar ? 'دخول آمن • HAX_TEAM' : 'SECURE ACCESS • HAX_TEAM');
  set('.input-label-cyber', ar ? 'مفتاح الدخول' : 'ACCESS KEY');
  set('#paste-btn', ar ? 'لصق' : 'PASTE');
  set('#unlock-btn', ar ? 'تحقق' : 'UNLOCK');
  const hint = document.querySelector('.login-hint');
  if (hint) hint.innerHTML = ar ? 'ليس لديك مفتاح؟ تواصل مع البائع.<br><span>يبدأ الوقت عند التفعيل.</span>' : 'No key? Contact your seller.<br><span>Time starts upon activation.</span>';
  const langBtn = document.getElementById('login-lang-toggle');
  if (langBtn) langBtn.textContent = ar ? 'العربية' : 'EN / AR';
}

document.addEventListener('DOMContentLoaded', async () => {
  const keyInput = document.getElementById('access-key-input');
  const unlockBtn = document.getElementById('unlock-btn');
  const loginLangBtn = document.getElementById('login-lang-toggle');
  if (loginLangBtn) loginLangBtn.addEventListener('click', () => {
    state.lang = state.lang === 'en' ? 'ar' : 'en';
    localStorage.setItem('powerup_lang', state.lang);
    updateLoginLanguage();
  });
  if (loginLangBtn) updateLoginLanguage();

  if (keyInput) {
    keyInput.addEventListener('input', (e) => {
      keyInput.value = formatKey(e.target.value);
    });
  }

  async function authenticate(inputKey, isRestore = false) {
    if (!inputKey) {
      alert(tr('Please enter your access key.', 'يرجى إدخال مفتاح الدخول.'));
      return false;
    }
    if (unlockBtn) {
      unlockBtn.disabled = true;
      unlockBtn.textContent = tr('AUTHENTICATING...', 'جارٍ التحقق...');
    }
    try {
      const dev = await getRealClientDevice();
      const res = await fetch(CONFIG.AUTH_API_URL, {
        method: 'POST',
        cache: 'no-store',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: inputKey, hwid: dev.hwid, device_model: dev.device_model, device_os: dev.device_os })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.ok || !data.me) {
        localStorage.removeItem('powerup_session');
        if (!isRestore) alert(data.error || tr('Invalid key.', 'المفتاح غير صالح.'));
        else alert(data.error || tr('Your saved key is no longer valid.', 'المفتاح المحفوظ لم يعد صالحاً.'));
        return false;
      }
      state.auth.loggedIn = true;
      state.auth.key = inputKey;
      state.auth.me = { ...state.auth.me, ...data.me };
      localStorage.setItem('powerup_session', JSON.stringify({ key: inputKey, me: state.auth.me }));
      pendingSavedSession = null;
      renderDashboard();
      return true;
    } catch (err) {
      console.error('Key verification failed:', err);
      if (isRestore) {
        if (keyInput) keyInput.value = formatKey(inputKey);
        alert(tr('Could not reach the license server. Press Verify to retry.', 'تعذر الاتصال بسيرفر التحقق. اضغط تحقق للمحاولة مجدداً.'));
      } else {
        alert(tr('Network error. Please try again.', 'خطأ في الاتصال. حاول مجدداً.'));
      }
      return false;
    } finally {
      if (unlockBtn && !state.auth.loggedIn) {
        unlockBtn.disabled = false;
        unlockBtn.textContent = tr('UNLOCK', 'تحقق');
      }
    }
  }

  if (pendingSavedSession && pendingSavedSession.key) {
    await authenticate(pendingSavedSession.key, true);
  }

  if (unlockBtn) {
    unlockBtn.addEventListener('click', async () => {
      const val = keyInput ? keyInput.value.trim() : '';
      await authenticate(val, false);
    });
  }
});

function formatKey(val) {
  return (val.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 19).match(/.{1,4}/g) ?? []).join('-');
}

async function getRealClientDevice() {
  let hwid = localStorage.getItem('powerup_hwid');
  if (!hwid) {
    hwid = `PWUP-${Math.random().toString(16).slice(2, 10).toUpperCase()}`;
    localStorage.setItem('powerup_hwid', hwid);
  }
  return { hwid, device_model: 'Android Device', device_os: 'Android' };
}
