export const CONFIG = {
  "BRAND_WORDMARK": "HAX_TEAM",
  "BRAND_TAGLINE": "HAX_TEAM secure access portal.",
  "AUTH_API_URL": "/api/redeem",
  "KEY_PREFIX": "HAXT",
  "KEY_PLACEHOLDER": "HAXT-XXXX-XXXX-XXXX",
  "IS_XREG": false,
  "SOCIAL_DISCORD_URL": "https://discord.gg/Km6Hsxk7Y4",
  "SOCIAL_TELEGRAM_URL": "",
  "SOCIAL_WHATSAPP_URL": "",
  "HAPP_IOS_URL": "https://apps.apple.com/app/happ-proxy-utility/id6504287u", // روابط Happ VPN الأصلية
  "HAPP_ANDROID_URL": "https://play.google.com/store/apps/details?id=com.happ.proxy", // رابط تطبيق Happ الرسمي
  "HAPP_SUBSCRIPTION_URL": "happ://crypt5/fzvdVQs0SgSbLZcjaeIN9XSV143WQI4H4uqshXgbj2TS891p24HRQnVXYzvfgbRg4UXLaC1r8eGw6oWU9AcdwiM0tOFJpffTscrSXYDL5l2IyAOS4rZ39H+mae7ty124Ghk7OxZTk65kvFqCTjPgtd/oKvggfGjEln6MrhY/vboJjiQ30nblu2RjcTqUyIxC3/2RxyXiqwcxeGvoYbN9GoSOwG0nJIq4O2BgMADFqRt4HxNgfVaSCFqVawMFMWT/1qlfXezFcFlxnwn8dqoayb1OPsHpRCnC+vGozEbM7o41kEe74LrtK8II2NMtK15n/w5XszaU3T+VRsv3nS1DzPKqtbNvbMhtQIKgp9w68XeF0YuwO9eKTGEF9NjMQwMVLgC/3zJgPibhDY8eFNZI7k4rMdfm4iKK6SygFySGecMV2oNSAEGPmYK5sg3wbzqtlM65GHla7IFZtwwddMI9645cpdYX/hqov3QIBA8+vI+7cxdw5amykxg7ugqm6/P0Fel0Z/KaMg0E/sQC+Y1qbYF2IbJPILHO81fII3Lu86F772iYdcdhm0TFHs1Iv1om12wJztfSzBebtDB4d40gL+IkXkObz6AbAPV9CAFKd7XF0aaUAoGILMF1sUDwGMy8lMIiY+CD4NrFiQvjKWOU0Y9o3jr/NTPVkfIqaWI+cNHYoBpluarCHVKmdx9uYWXnUfg3JcgJ2fVEglWZmoDKaI3nZ4NFZIoZT8ItlIWhKoypUVemcdflJ/McJak3L0YNzfDbr6QuJnmyioj8imLoRtrYOp+uqb2DBw0tkx2Szi/VQBO38IngSrH0GDfl+RzKVdzUVqDtWGF+laZIIgz1FtzlfoA=ff",
  "MARKER_TYPES": [
    "Power",
    "Phantom",
    "Dreamland",
    "Ice Wall",
    "Moco",
    "Clu",
    "Shirou",
    "Iris",
    "Dreki"
  ],
  "DEFAULT_FEATURES": {
    "marker": {
      "enabled": true,
      "type": "Power"
    },
    "aimLag": {
      "enabled": false,
      "onFire": false,
      "onScope": false
    },
    "fastLanding": {
      "enabled": false,
      "spot": "Peak"
    },
    "fastRevive": {
      "enabled": false
    },
    "gloo": {
      "enabled": false,
      "yawDeg": 180
    },
    "aimpoint": {
      "enabled": false
    }
  },
  "UPDATE_NOTES": [
    {
      "version": "v1.7",
      "title": "HAX_TEAM System Launch",
      "body": "Welcome to HAX_TEAM. Secure access portal updated."
    }
  ]
};
export default CONFIG;
